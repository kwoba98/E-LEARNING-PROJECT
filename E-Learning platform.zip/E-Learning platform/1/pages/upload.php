<?php
include 'inc/header.php';
$title = "Upload Lecture Detailes";
header($title);
Session::CheckSession();

 ?>
<style>
.form{
width: 100%;
display: inline-block;
position: inherit;
padding: 6px;
}

.label {
padding: 10px;
width: 10%;
}
.input{
position: inherit;
padding: 3px;
margin-left: 2.3%;
}

.btn{
margin-left: 6.5%;
background-color: blue;
color: white;
}
</style>
<?php
$con = mysqli_connect("localhost","root","","db_admin");
if (mysqli_connect_errno()) {
echo "Unable to connect to MySQL! ". mysqli_connect_error();
}
if (isset($_POST['save'])) {
$target_dir = "Uploaded_Files/";
$target_file = $target_dir . date("dmYhis") . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if($imageFileType != "mkv" || $imageFileType != "mp4" || $imageFileType != "xlsl" || $imageFileType != "ppt" ) {
if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
$files = date("dmYhis") . basename($_FILES["file"]["name"]);
}else{
echo "Error Uploading File";
exit;
}
}else{
echo '"File Not Supported"';
exit;
}
$lecture = $_POST['lecture'];
$lecturer = $_POST['lecturer'];
$topic = $_POST['topic'];
$description = $_POST['description'];
$course = $_POST['course'];
$location = "Uploaded_Files/" . $files;

$sqli = "INSERT INTO `tblfiles` (`lecture`, `lecturer`, `topic`, `description`, `course`, `Location`) VALUES ('{$lecture}','{$lecturer}','{$topic}','{$description}','{$course}','{$location}')";
$result = mysqli_query($con,$sqli);
if ($result) {
echo '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Success !</strong> Detailes uploaded successively!</div>';
};
}
?>
 <div class="card ">
  <div class="card-header">
    <h3><i class="fas fa-book mr-2"></i>Upload Lectures <span class="float-right">Hello! 
      <strong>
        <span class="badge badge-lg badge-success text-white">
          <?php
          $username = Session::get('username');
          if (isset($username)) {
            echo $username;
          }
           ?>
        </span>
      </strong></span>
    </h3>
  </div>
  <div class="card-body">
    <div style="width:600px; margin:0px auto">
      <form class="form" method="post" action="" enctype="multipart/form-data">
        <div class="form-group">
          <label>Lecture No:</label>
          <input type="number" name="lecture" class="form-control" required>
          <div class="invalid-feedback">
              Please provide a valid number.
            </div>
        </div>
        <div class="form-group">
          <label for="email">Lecturer:</label>
          <input type="text" id="lecturer" name="lecturer" class="form-control">
        </div>
        <div class="form-group">
          <label for="email">Topic:</label>
          <input type="text" id="topic" name="topic" class="form-control">
        </div>
        <div class="form-group">
          <label for="email">Topic:</label>
          <input type="text" id="description" aria-label="With textarea" name="description" class="form-control">
        </div>
        <div class="form-group">
          <label>Choose course:</label>
          <select id="course" name="course" class="form-control">
            <option>Bachelor in Telecome</option>
            <option>Diploma in Telecome</option>
            <option>Bachelor in Electrical</option>
            <option>Diploma in Telecome</option>
            <option>Diploma in Computer</option>
            <option>Diploma in Biomedical</option>
            <option>Bachelor in Biomedical</option>
          </select>
        </div>
        <div class="form-group">
          <label>Video:</label>
          <input type="file" name="file" id="customFile">
        </div>
        
        <button type="submit" name="save" class="btn float-right"><i class="fa fa-upload"></i> Upload</button>
      </form>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript">
</script>