-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2022 at 03:29 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblfiles`
--

CREATE TABLE `tblfiles` (
  `ID` int(11) NOT NULL,
  `Location` varchar(90) NOT NULL,
  `lecture` varchar(256) NOT NULL,
  `lecturer` varchar(256) NOT NULL,
  `topic` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `course` varchar(256) NOT NULL,
  `time` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblfiles`
--

INSERT INTO `tblfiles` (`ID`, `Location`, `lecture`, `lecturer`, `topic`, `description`, `course`, `time`) VALUES
(28, 'Uploaded_Files/04022022022109Teni - Uyo Meyo (Official Audio).mp4', '1', 'Moses Okiror', 'signal proccessing', 'fourier functions and descret functions', 'Bachelor in Telecome', '2022-02-06'),
(29, 'Uploaded_Files/060220220820221da Banton - No Wahala (Official Video).mp4', '2', 'Moses Okiror 2', 'signal proccessing 2', 'signal proccessing 2', 'Bachelor in Electrical', '2022-02-06'),
(30, 'Uploaded_Files/06022022023527Oxlade - Ojuju (Official Video).mp4', '1', '3', 'big flex', 'testing', 'Diploma in Computer', '2022-02-06'),
(31, 'Uploaded_Files/06022022023938Jaywillz - Medicine (Official Video).mp4', '4', 'ojuju', 'ox;ade', 'falling', 'Bachelor in Electrical', '2022-02-06'),
(32, 'Uploaded_Files/08022022065313Maxwell.docx', '6', 'tree', 'trap', 'topic', 'Diploma in Computer', '2022-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `id` int(11) NOT NULL COMMENT 'role_id',
  `role` varchar(255) DEFAULT NULL COMMENT 'role_text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_roles`
--

INSERT INTO `tbl_roles` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Editor'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `stdnbr` varchar(25) DEFAULT NULL,
  `course` varchar(256) NOT NULL,
  `roleid` tinyint(4) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `username`, `email`, `password`, `stdnbr`, `course`, `roleid`, `isActive`, `created_at`, `updated_at`) VALUES
(7, 'Okiror', 'Mosh', 'moshjs63@gmail.com', '7f3b556ec781a90ea7b02766f4ba508501569070', '01717090233', 'B Telecom', 1, 0, '2020-03-12 16:23:01', '2020-03-12 16:23:01'),
(27, 'ken', 'ken', 'ken@gmail.com', 'f1d95535e6275da5b35a932ca3d6cb28d839615f', '12345678985434567', 'B Telecom3', 2, 0, '2022-02-03 22:09:08', '2022-02-03 22:09:08'),
(28, 'weed', 'weed', 'weed@gmail.com', '6d7abaebedaabd0db011050174fac86c5c07ce5d', '1234567890-03345678909876', 'Bachelor in Biomedical', 3, 0, '2022-02-04 12:37:34', '2022-02-04 12:37:34'),
(29, 'peter', 'peter', 'peter@gmail.com', '430158fe458a9188e6acfe43c7c7f5b8ae7f6a7c', '123456789', 'Bachelor in Telecome', 2, 1, '2022-02-08 06:01:23', '2022-02-08 06:01:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblfiles`
--
ALTER TABLE `tblfiles`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblfiles`
--
ALTER TABLE `tblfiles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'role_id', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
